For Cemu: Put in sharedFonts
For decaf: Put in resources\fonts